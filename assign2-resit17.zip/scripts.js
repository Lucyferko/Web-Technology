// https://www.w3schools.com/howto/howto_js_filter_table.asp ; https://stackoverflow.com/questions/51187477/how-to-filter-a-html-table-using-simple-javascript ; https://api.jquery.com/ ;  https://developer.mozilla.org/en-US/docs/Web/JavaScript .  .

function createAuthorFilter(data) {
    // get unique author names from the data
    let authors = new Set();
    for (let i = 0; i < data.length; i++) {
        authors.add(data[i].author);
    }

    // create a clickable element for each author and add it to the filter container
    let filterContainer = $("#author-filter-container");
    for (let author of authors) {
        let authorElement = $("<span>").text(author).addClass("author-filter");
        authorElement.click(function() {
            filterByAuthor(author);
        });
        filterContainer.append(authorElement);
    }
}

$.get("https://wt.ops.labs.vu.nl/api23/fedb0b95", function(download){
            refreshProductTable($("#productTable"), download);
            createAuthorFilter(download);
});

function filterByAuthor(author) {
    // hide all images that don't match the selected author
    $("#productTable tbody tr td:first-child").filter(function() {
        return $(this).text() !== author;
    }).parent().hide();

    // show all images that match the selected author
    $("#productTable tbody tr td:first-child").filter(function() {
        return $(this).text() === author;
        }).parent().show();
        
        // add a visual indicator to the selected author
        $(".author-filter").removeClass("selected");
        $(".author-filter").filter(function() {
            return $(this).text() === author;
        }).addClass("selected");
        }

// OLD
// helper function for swapping rows in a table:

function swapRows(rowOne, rowTwo) {
    rowOne.replaceWith(rowTwo);
    rowTwo.after(rowOne);
    return;
}

// sorting function using the bubble sort algorithm:

function sortTable(table, columnIndex, reversed, recursive = true) {

    let rows = table.children("tbody").children();
    let isSorted = false;
    let numberOfChanges = 0;
    let d = 1;

    if (reversed) {
        d = -1;
    }

    while (!isSorted) {
        isSorted = true;

        for (let i=0; i<rows.length - 1; i++) {
            rows = table.children("tbody").children().not(".inputRow");
            let firstRow = rows.eq(i);
            let secondRow = rows.eq(i + 1);
            let firstVal = firstRow.children().eq(columnIndex).text();
            let secondVal = secondRow.children().eq(columnIndex).text();

            if (firstVal.localeCompare(secondVal, undefined, { numeric: true }) == d) {
                swapRows(firstRow, secondRow);
                isSorted = false;
                numberOfChanges++;
            }
        }
    }

    // the code below automatically sorts in the opposite direction
    // if the table is already sorted

    if (numberOfChanges == 0 && recursive) {
        sortTable(table, columnIndex, !reversed, false);
    }

    return;
}

// table content refresh, WIPES the table and inserts ALL data from the server:

function refreshProductTable(table, data) {

    table.children("tbody").children().not(".inputRow").remove();

    for (i in data) {

        let lastRow = table.children("tbody").children();
        lastRow = lastRow.eq(lastRow.length - 1);

        let insert = "";
        insert += "<tr>"
        insert += "<td>" + data[i].author + "</td>";
        insert += "<td>" + data[i].description + "</td>";
        insert += "<td>" + data[i].tags + "</td>";
        insert += "<td>" + data[i].alt + "</td>";
        insert += "<td><img src='" + data[i].image + "' alt='" + data[i].alt + "'></td>";
        insert += "</tr>";

        lastRow.before(insert);
    }

    return;
}

// listeners:
  
$("#productTable").ready( 
    function(){
        $.get("https://wt.ops.labs.vu.nl/api23/fedb0b95", function(download){
            refreshProductTable($("#productTable"), download);
        });
    }
);

$("th").click(
    function(){
        sortTable($(this).parents("table"), $(this).index(), false);
        $(this).siblings().css("background-color", "black");
        $(this).siblings().css("color", "white");
        $(this).css("background-color", "white");
        $(this).css("color", "black");
    }
);

$("#reset").click(
    function(){
        $.get("https://wt.ops.labs.vu.nl/api23/fedb0b95/reset");

        $.get("https://wt.ops.labs.vu.nl/api23/fedb0b95", function(download){
            refreshProductTable($("#productTable"), download);
        });
    }
);

// listen for form submission NEW
$("form").on("submit", function(event) {
    event.preventDefault();

    // collect form data
    var formData = {
        author: $("#author").val(),
        description: $("#description").val(),
        tags: $("#tags").val(),
        alt: $("#alt").val(),
        image: $("#image").val()
    };

    // convert form data to JSON
    var jsonData = JSON.stringify(formData);

    // send form data to server
    fetch("https://wt.ops.labs.vu.nl/api23/fedb0b95", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: jsonData
    })
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        $.get("https://wt.ops.labs.vu.nl/api23/fedb0b95", function(download){
            refreshProductTable($("#productTable"), download);
        });
        $("#author").val("");
        $("#description").val("");
        $("#tags").val("");
        $("#alt").val("");
        $("#image").val("");
    })
    .catch(function(error) {
        console.log(error);
    });
    });

$("#update-button").click(function(){
    let id = $(".input").val();
    let data = {
        "author": $("#author").val(),
        "description": $("#description").val(),
        "tags": $("#tags").val(),
        "alt": $("#alt").val(),
        "image": $("#image").val()
    }

    fetch("https://wt.ops.labs.vu.nl/api23/fedb0b95/item/" + id, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        return response.json();
    })
    .then(data => {
        refreshProductTable($("#productTable"), data, id);
    })
    .catch(error => {
        console.log(error);
        });
    });
    
    
